﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Collections;

namespace WindowsFormsApp15
{
    class PredmetUkazatel
    {
        public ArrayList index = new ArrayList();

        public void SoxranitVFile(string fileName, List<string> list)
        {
            using (StreamWriter writer = new StreamWriter(fileName))
            {
                foreach (var item in list)
                {
                    writer.WriteLine(item.ToString());
                }
            }
            MessageBox.Show("Информация успешно записана в файл.");
        }

        public void ZagruzitVFile(string fileName)
        {
            foreach (var line in File.ReadAllLines(fileName))
            {
                string[] parts = line.Split(new char[] { ':' }, 2);
                string key = parts[0].Trim();
                string[] values = parts[1].Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                var valueList = new ArrayList();
                foreach (string value in values)
                {
                    valueList.Add(int.Parse(value.Trim()));
                }
                var pair = new DictionaryEntry(key, valueList);
                index.Add(pair);
            }
        }

        public List<int> PoiskInArrayList(string slovo)
        {
            string[] parts = slovo.Split(new char[] { ':' }, 2);
            string keys = parts[0].Trim();
            string value = parts[1].Trim();

            List<int> resultList = new List<int>();
            foreach (DictionaryEntry entry in index)
            {
                string key = (string)entry.Key;
                if (key.StartsWith(keys))
                {
                    ArrayList arrayList = (ArrayList)entry.Value;
                    IEnumerable<int> intEnumerable = arrayList.Cast<int>();

                    foreach (var item in intEnumerable)
                    {
                        if (item.ToString().Contains(value))
                        {
                            resultList.AddRange(intEnumerable);
                        }
                    }
                }
            }

            return resultList;
        }

        public List<int> Poisk(string search, bool isNumber, int page)
        {
            List<int> result = new List<int>();

            if (isNumber)
            {
                int number = int.Parse(search);
                if (number == page)
                {
                    result.Add(number);
                }
            }
            else
            {
                if (search.Contains(page.ToString()))
                {
                    result.Add(page);
                }
            }
            return result;
        }



    }
}
